# Connected Devices - Python

Connected Devices - Python repository.

Please see the LICENSE file located in ./apps/labbenchstudios for information
on using the source code provided in, and under, ./apps/labbenchstudios.
=======
**Edit a file, create a new file, and clone from Bitbucket in under 2 minutes**
